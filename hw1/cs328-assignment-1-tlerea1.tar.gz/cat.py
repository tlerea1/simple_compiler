import sys


while 1:
	line = sys.stdin.readline()
	if not line:
		break
	sys.stdout.write(line)
